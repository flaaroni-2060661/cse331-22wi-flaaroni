/*
 * Copyright (C) 2022 Hal Perkins.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Winter Quarter 2022 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

import React, { Component } from "react";
import EdgeList from "./EdgeList";
import Map from "./Map";

// Allows us to write CSS styles inside App.css, any styles will apply to all components inside <App />
import "./App.css";
import MapLine from "./MapLine";


interface AppState {
    parsedLines: (JSX.Element)[]
}

class App extends Component<{}, AppState> {

  constructor(props: {}) {
    super(props);
    this.state = {
        parsedLines: [],
    };
  }

  render() {
    return (
      <div>
        <h1 id="app-title">Line Mapper!</h1>
        <div>
          <Map  parsedLines={this.state.parsedLines}/>
        </div>
        <EdgeList
          onChange={(value) => {
              let mapLines : JSX.Element[] = [];
              let lines : string[] = value.split("\n");
              if (lines.length === 5){
              }
              for(let i = 0; i < lines.length; i++){
                  let edgeData : string[] = lines[i].split(" ");
                      if (edgeData.length === 5){
                          let edge1 : number = parseInt(edgeData[0]);
                          let edge2 : number = parseInt(edgeData[1]);
                          let edge3 : number = parseInt(edgeData[2]);
                          let edge4 : number = parseInt(edgeData[3]);
                          if (!(edge1 > 4000 || edge1 < 0 || edge2 > 4000 || edge2 < 0 || edge3 > 4000 || edge3 < 0 ||
                              edge4 > 4000 || edge4 < 0)){
                              let color : string = edgeData[4];
                              let line : JSX.Element =<MapLine x1={edge1} y1={edge2} x2={edge3} y2={edge4} color = {color}/>
                              mapLines.push(line);
                      }
                  }
              }
            this.setState({
                parsedLines: mapLines,
            })
          }}
        />
      </div>
    );
  }
}

export default App;
