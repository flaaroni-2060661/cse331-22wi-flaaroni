/*
 * Copyright (C) 2022 Hal Perkins.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Winter Quarter 2022 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */
/*
 * Copyright (C) 2022 Hal Perkins.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Winter Quarter 2022 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */




package pathfinder.scriptTestRunner;
import graph.Edge;
import graph.EdgeComparator;
import graph.MyGraph;
import marvel.MarvelGraph;
import pathfinder.FindWeightedPath;
import pathfinder.datastructures.Point;
import pathfinder.datastructures.Path;
import java.io.*;
import java.util.*;
import java.io.Reader;
import java.io.Writer;

/**
 * This class implements a test driver that uses a script file format
 * to test an implementation of Dijkstra's algorithm on a graph.
 */
public class PathfinderTestDriver {

    private final Map<String, MyGraph<String, Double>> graphs = new HashMap<String, MyGraph<String, Double>>();
    private final PrintWriter output;
    private final BufferedReader input;

    // Leave this constructor public
    public PathfinderTestDriver(Reader r, Writer w) {
        input = new BufferedReader(r);
        output = new PrintWriter(w);
    }

    // Leave this method public
    public void runTests() throws IOException {
        String inputLine;
        while((inputLine = input.readLine()) != null) {
            if((inputLine.trim().length() == 0) ||
                    (inputLine.charAt(0) == '#')) {
                // echo blank and comment lines
                output.println(inputLine);
            } else {
                // separate the input line on white space
                StringTokenizer st = new StringTokenizer(inputLine);
                if(st.hasMoreTokens()) {
                    String command = st.nextToken();

                    List<String> arguments = new ArrayList<>();
                    while(st.hasMoreTokens()) {
                        arguments.add(st.nextToken());
                    }

                    executeCommand(command, arguments);
                }
            }
            output.flush();
        }
    }

    private void executeCommand(String command, List<String> arguments) {
        try {
            switch(command) {
                case "CreateGraph":
                    createGraph(arguments);
                    break;
                case "AddNode":
                    addNode(arguments);
                    break;
                case "AddEdge":
                    addEdge(arguments);
                    break;
                case "ListNodes":
                    listNodes(arguments);
                    break;
                case "ListChildren":
                    listChildren(arguments);
                    break;
                case "LoadGraph":
                    loadGraph(arguments);
                    break;
                case "FindPath":
                    findWeightedPath(arguments);
                    break;
                default:
                    output.println("Unrecognized command: " + command);
                    break;
            }
        } catch(Exception e) {
            String formattedCommand = command;
            formattedCommand += arguments.stream().reduce("", (a, b) -> a + " " + b);
            output.println("Exception while running command: " + formattedCommand);
            e.printStackTrace(output);
        }
    }

    private void createGraph(List<String> arguments) {
        if(arguments.size() != 1) {
            throw new CommandException("Bad arguments to CreateGraph: " + arguments);
        }

        String graphName = arguments.get(0);
        createGraph(graphName);
    }

    private void createGraph(String graphName) {
        graphs.put(graphName, new MyGraph<String, Double>());
        output.println("created graph " + graphName);
    }

    private void addNode(List<String> arguments) {
        if(arguments.size() != 2) {
            throw new CommandException("Bad arguments to AddNode: " + arguments);
        }

        String graphName = arguments.get(0);
        String nodeName = arguments.get(1);
        addNode(graphName, nodeName);
    }

    private void addNode(String graphName, String nodeName) {
        MyGraph<String, Double> temp = graphs.get(graphName);
        temp.addNode(nodeName);
        graphs.replace(graphName, temp);
        output.println("added node " + nodeName + " to " + graphName);
    }

    private void addEdge(List<String> arguments) {
        if(arguments.size() != 4) {
            throw new CommandException("Bad arguments to AddEdge: " + arguments);
        }

        String graphName = arguments.get(0);
        String parentName = arguments.get(1);
        String childName = arguments.get(2);
        String edgeLabel = arguments.get(3);

        addEdge(graphName, parentName, childName, Double.parseDouble(edgeLabel));
    }

    private void addEdge(String graphName, String parentName, String childName,
                         Double edgeLabel) {
        MyGraph<String, Double> temp = graphs.get(graphName);
        temp.addGraphEdge(parentName, childName, edgeLabel);
        graphs.replace(graphName, temp);
        output.println("added edge " + String.format("%.3f", edgeLabel) + " from " + parentName + " to " + childName + " in " +
                graphName);
    }

    private void listNodes(List<String> arguments) {
        if(arguments.size() != 1) {
            throw new CommandException("Bad arguments to ListNodes: " + arguments);
        }

        String graphName = arguments.get(0);
        listNodes(graphName);
    }

    private void listNodes(String graphName) {
        MyGraph<String, Double> temp = graphs.get(graphName);
        if (temp == null){
            output.println(graphName + " contains:");
        } else {
            List<String> nodes = temp.getNodes();
            String result = graphName + " contains:";
            for (String s : nodes) {
                result += " " + s;
            }
            output.println(result);
        }
    }

    private void listChildren(List<String> arguments) {
        if(arguments.size() != 2) {
            throw new CommandException("Bad arguments to ListChildren: " + arguments);
        }

        String graphName = arguments.get(0);
        String parentName = arguments.get(1);
        listChildren(graphName, parentName);
    }

    private void listChildren(String graphName, String parentName) {
        MyGraph<String, Double> tempGraph = graphs.get(graphName);
        String result = "the children of " + parentName + " in " + graphName + " are:";
        List<Edge<Double, String>> edges = tempGraph.graph.get(parentName);
        EdgeDoubleComparator comparator = new EdgeDoubleComparator();
        edges.sort(comparator);
        for (Edge<Double, String> e : edges){
            result += " " + e.getChildNode() + "(" + e.getLabel() + ")";
        }
        output.println(result);
    }

    private void loadGraph(List<String> arguments){
        if(arguments.size()!= 2){
            throw new CommandException("Bad arguments to LoadGraph: " + arguments);
        }
        String graphName = arguments.get(0);
        String fileName = arguments.get(1);
        loadGraph(graphName, fileName);
    }

    private void loadGraph(String graphName, String fileName){
        MyGraph<String, Double> test = graphs.get(graphName);
        this.graphs.put(graphName, test);
        output.println("loaded graph " + graphName);
    }

    private void findWeightedPath(List<String> arguments){
        if (arguments.size() != 3){
            throw new CommandException("Bad arguments to findPath: " + arguments);
        }
        String graphName = arguments.get(0);
        String start = arguments.get(1);
        String dest = arguments.get(2);
        findWeightedPath(graphName, start, dest);
    }

    private void findWeightedPath(String graphName, String start, String dest){
        MyGraph<String, Double> graph = this.graphs.get(graphName);
        start = start.replaceAll("_", " ");
        dest = dest.replaceAll("_", " ");
        if (!graph.containsNode(start)){
            output.println("unknown: " + start);
        }
        if (!graph.containsNode(dest)){
            output.println("unknown: " + dest);
        }
        if (graph.containsNode(start) && graph.containsNode(dest)){
            Path<String> path = FindWeightedPath.findWeightedPath(graph, start, dest);
            output.println("path from " + start + " to " + dest + ":");
            if (path == null){
                output.println("no path found");
            } else {
                for (Path<String>.Segment e : path) {
                    output.println(e.getStart() + " to " + e.getEnd() + " with weight " +
                            String.format("%.3f", e.getCost()));
                }
                output.println("total cost: " + String.format("%.3f", path.getCost()));
            }
        }
    }

    /**
     * This exception results when the input file cannot be parsed properly
     **/
    static class CommandException extends RuntimeException {

        public CommandException() {
            super();
        }

        public CommandException(String s) {
            super(s);
        }

        public static final long serialVersionUID = 3495;
    }

    public static class EdgeDoubleComparator implements Comparator<Edge<Double, String>>{
        public int compare(Edge<Double, String> o1, Edge<Double, String> o2){
            int result = o1.getChildNode().compareTo(o2.getChildNode());
            if(result == 0){
                result = o1.getLabel().compareTo(o2.getLabel());
            }
            return result;
        }
    }
}
