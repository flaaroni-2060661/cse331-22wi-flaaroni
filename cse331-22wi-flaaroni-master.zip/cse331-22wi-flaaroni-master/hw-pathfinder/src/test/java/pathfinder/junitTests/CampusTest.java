package pathfinder.junitTests;

import org.junit.Test;
import pathfinder.CampusMap;
import pathfinder.datastructures.Path;
import pathfinder.datastructures.Point;

public class CampusTest {
    @Test
    public void buildMap(){
        CampusMap test = new CampusMap();
        Path path = test.findShortestPath("LOW", "CS2");
    }
}
