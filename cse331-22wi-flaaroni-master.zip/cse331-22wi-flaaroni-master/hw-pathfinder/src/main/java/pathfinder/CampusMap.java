/*
 * Copyright (C) 2022 Hal Perkins.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Winter Quarter 2022 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

package pathfinder;

import graph.Edge;
import graph.MyGraph;
import pathfinder.datastructures.Path;
import pathfinder.datastructures.Point;
import pathfinder.parser.CampusBuilding;
import pathfinder.parser.CampusPath;
import pathfinder.parser.CampusPathsParser;

import java.util.*;

public class CampusMap implements ModelAPI {

    private final MyGraph<Point, Double> campusGraph;
    private final List<CampusBuilding> buildings;

    public CampusMap (){
        campusGraph = new MyGraph<>();
        buildings = CampusPathsParser.parseCampusBuildings("campus_buildings.csv");
        List<CampusPath> paths = CampusPathsParser.parseCampusPaths("campus_paths.csv");
        for (CampusPath path : paths){
            campusGraph.addNode(new Point(path.getX1(), path.getY1()));
        }
        for (CampusPath path : paths){
            campusGraph.addGraphEdge(new Point(path.getX1(), path.getY1()), new Point(path.getX2(), path.getY2()),
                    path.getDistance());
        }
    }

    /**
     * Tests whether a given shortName is in the graph or not
     * @param shortName The short name of a building to query.
     * @return whether shortName is in the graph
     */
    @Override
    public boolean shortNameExists(String shortName) {
        for (CampusBuilding building : buildings){
            if (building.getShortName().equals(shortName)){
                return true;
            }
        }
        return false;
    }

    /**
     * Searches and returns the longName corresponding with the shortName
     * @param shortName The short name of a building to look up.
     * @return the longName corresponding with the shortName
     * @throws IllegalArgumentException if the name doesn't exist
     */
    @Override
    public String longNameForShort(String shortName) throws IllegalArgumentException{
        for (CampusBuilding building : buildings){
            if (building.getShortName().equals(shortName)){
                return building.getLongName();
            }
        }
        throw new IllegalArgumentException("shortname not found");
    }

    /**
     * Searches and returns a list of all buildings with both short and long names
     * @return the list of all buildings
     */
    @Override
    public Map<String, String> buildingNames() {
        Map<String, String> names = new HashMap<>();
        for (CampusBuilding building : buildings){
            names.put(building.getShortName(), building.getLongName());
        }
        return names;
    }

    /**
     * Searches and finds the shortest path from startShortName to endShortName
     * @param startShortName The short name of the building at the beginning of this path.
     * @param endShortName   The short name of the building at the end of this path.
     * @return the path starting from startShortName to endShortName
     * @throws IllegalArgumentException if the path doesn't exist
     */
    @Override
    public Path<Point> findShortestPath(String startShortName, String endShortName) throws IllegalArgumentException{
        if (!this.shortNameExists(startShortName) || !this.shortNameExists(endShortName)){
            System.out.println(startShortName);
            System.out.println(endShortName);
            throw new IllegalArgumentException("name doesn't exist");
        } else if (startShortName == null || endShortName == null){
            throw new IllegalArgumentException("name is null");
        }
        Point start = null;
        Point end = null;
        for (CampusBuilding building : buildings){
            if (building.getShortName().equals(startShortName)){
                start = new Point(building.getX(), building.getY());
            } else if (building.getShortName().equals(endShortName)){
                end = new Point(building.getX(), building.getY());
            }
        }
        return FindWeightedPath.findWeightedPath(campusGraph, start, end);
    }


}
