package pathfinder;

import graph.Edge;
import graph.MyGraph;
import pathfinder.datastructures.Path;
import pathfinder.datastructures.Point;
import pathfinder.parser.CampusBuilding;

import java.util.Comparator;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Set;

public class FindWeightedPath{


    /**
     * Finds the path with the lowest cost in graph from building start to building end
     * @param graph the graph being searched
     * @param start the start of the path
     * @param end the end of the path
     * @param <N> Datatype of the path
     * @param <E> Datatype of the path
     * @return the path with the shortest distance from start to end
     */
    public static <N, E extends Double> Path<N> findWeightedPath(MyGraph<N, E> graph, N start, N end){
        Set<N> finished = new HashSet<N>();
        PriorityQueue<Path<N>> active = new PriorityQueue<Path<N>>(new PathComparator<N>());
        active.add(new Path<N>(start));
        while (!active.isEmpty()) {
            Path<N> minPath = active.remove();
            N minDest = minPath.getEnd();
            if (minDest.equals(end)) {
                return minPath;
            }
            if (finished.contains(minDest)) {
                continue;
            }
            for (Edge<E, N> child : graph.viewChildren(minDest)) {
                if (!finished.contains(child.getChildNode())) {
                    Path<N> p = minPath.extend(child.getChildNode(), child.getLabel());
                    active.add(p);
                }
            }
            finished.add(minDest);
        }
        return null;
    }

    /**
     * Compares two Path<N> classes to each other
     * @param <N> The datatype of the path
     */

    private static class PathComparator<N> implements Comparator<Path<N>> {
        @Override
        public int compare(Path<N> o1, Path<N> o2) {
            double result = o1.getCost() - o2.getCost();
            if (result < 0) {
                return -1;
            } else if (result > 0) {
                return 1;
            } else {
                return 0;
            }
        }
    }
}
