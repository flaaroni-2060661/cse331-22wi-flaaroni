package graph;

import java.util.*;

// Abstraction function: Contains a name and pairs of references to other GraphNodes and a name
// Inv: name != null, key/data from edges != null, key from edges contains an already existing GraphNode
public class GraphNode {
    // each node contains a name and a list of nodes it's connected to paired with a label
    private String name;
    private List<Edge> edges;

    // constructs a graph node using the given name
    public GraphNode(String name){
        this.name = name;
        this.edges = new ArrayList<Edge>();
    }

    public String getName(){
        return name;
    }

    public List<Edge> getEdges(){
        return new ArrayList<>(edges);
    }
}
