package graph;

import java.util.Comparator;

public class EdgeComparator implements Comparator<Edge<String, String>>{
    public int compare(Edge<String, String> o1, Edge<String, String> o2){
        int result = o1.getChildNode().compareTo(o2.getChildNode());
        if (result == 0) {
            result = o1.getLabel().compareTo(o2.getLabel());
        }
        return result;
    }
}
