package graph;



public class Edge <L, N>{
    private N parentNode;
    private N childNode;
    private L label;

    public Edge (N p, N c, L l){
        parentNode = p;
        childNode = c;
        label = l;

    }

    public N getChildNode(){
        return childNode;
    }

    public L getLabel(){
        return label;
    }

    public N getParentNode(){
        return parentNode;
    }

}
