package graph;

import java.util.*;

/**
 * Builds a graph made of nodes and edges
 */
public class MyGraph<N, E> {
    // Abstraction function: Set of GraphNode objects contained in this.MyGraph
// Inv: graph != null, each node in graph != null, parent/child node in each edge != null

    public Map<N, List<Edge<E, N>>> graph;

    /** Constructs an empty graph
     *
     */
    public MyGraph(){
        graph = new HashMap<N, List<Edge<E, N>>>();
    }

    /**
     * Returns a list of nodes from the graph
     * @return graph, the list of nodes
     */
    public List<N> getNodes(){
        return new ArrayList<>(graph.keySet());
    }

    /** adds a node without edges using label s
     *
     * @param s the node being added
     * @throws IllegalArgumentException if string is null
     */
    public void addNode(N s) throws IllegalArgumentException{
        if (s == null){
            throw new IllegalArgumentException("string is null");
        }
        graph.put(s, new ArrayList<Edge<E,N>>());
    }

    /**
     *
     * @param parentNode where the edge starts
     * @param childNode where the edge points to
     * @param label the name of the edge
     * @throws IllegalArgumentException if childNode or parentNode doesn't exist
     */
    public void addGraphEdge(N parentNode, N childNode, E label) throws IllegalArgumentException{
        if (!containsNode(childNode)){
            throw new IllegalArgumentException("childNode doesn't exist");
        } else if (!containsNode(parentNode)){
            throw new IllegalArgumentException("graphNode doesn't exist");
        }
        Edge<E, N> edge = new Edge<E, N>(parentNode, childNode, label);
        graph.get(parentNode).add(edge);
    }

    /**
     * tests if the graph contains a string associated with a given node
     *
     * @param g the node being searched
     * @return whether the graph contains the node
     */
    public boolean containsNode(N g) {
        return graph.containsKey(g);
    }

    /** Prints out all the edges that point to the node associated with the given string
     * @param s the string associated with the node that the method finds edges to
     * @return a list of nodes that g is connected to
     *
     */
    public Set<Edge<E, N>> viewChildren(N s){
        if (s == null) {
            return null;
        } else if (!graph.containsKey(s)) {
            return null;
        }
        return new HashSet<Edge<E, N>>(graph.get(s));
    }

    /**
     * checks the invariant
     * @throws IllegalArgumentException if invariant is broken
     */
    private void checkRep() throws IllegalArgumentException{
        if (this.graph == null){
            throw new IllegalArgumentException("null graph");
        }
        for(N g: graph.keySet()){
            if (g == null){
                throw new IllegalArgumentException("null node");
            }
            for(Edge<E, N> e : graph.get(g)) {
                if (e.getLabel() == null){
                    throw new IllegalArgumentException("null label");
                }
                if (e.getChildNode() == null){
                    throw new IllegalArgumentException("null childNode");
                }
                if (!graph.containsKey(e.getChildNode())){
                    throw new IllegalArgumentException("key doesn't exist");
                }
            }
        }
    }
}
