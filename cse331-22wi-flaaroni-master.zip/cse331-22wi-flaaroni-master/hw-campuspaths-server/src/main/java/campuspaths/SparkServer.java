/*
 * Copyright (C) 2022 Hal Perkins.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Winter Quarter 2022 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

package campuspaths;

import campuspaths.utils.CORSFilter;
import pathfinder.CampusMap;
import pathfinder.datastructures.Path;
import pathfinder.datastructures.Point;
import spark.Route;
import spark.Spark;
import spark.Response;
import spark.Request;
import com.google.gson.Gson;

import java.util.Map;

public class SparkServer {

    public static void main(String[] args) {
        CORSFilter corsFilter = new CORSFilter();
        corsFilter.apply();

        CampusMap campusMap = new CampusMap();

        Spark.get("/get-buildings", new Route(){
            @Override
            public Object handle(Request request, Response response) throws IllegalArgumentException{
                Map<String, String> buildings = campusMap.buildingNames();
                Gson gson = new Gson();
                return gson.toJson(buildings);
            }
        });

        Spark.get("/find-shortest-path", new Route(){
            @Override
            public Object handle(Request request, Response response) throws IllegalArgumentException{
                CampusMap campusMap = new CampusMap();
                String building1 = request.queryParams("building1");
                String building2 = request.queryParams("building2");
                if (!(campusMap.shortNameExists(building1) || campusMap.shortNameExists(building2))){
                    throw new IllegalArgumentException("path name doesn't exist");
                }
                Path<Point> path = campusMap.findShortestPath(building1, building2);
                Gson gson = new Gson();
                return gson.toJson(path);
            }
        });

    }

}
