/*
 * Copyright (C) 2022 Hal Perkins.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Winter Quarter 2022 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

import React, { Component } from "react";
import Map from "./Map";
import "./App.css";
import MapLine from "./MapLine";

interface AppState {
    buildingList: Record<string, string>;
    start: string;
    dest: string;
    parsedLines: (JSX.Element)[]
    path: Path;
}

interface Segment {
    cost: number;
    start: {
        x: number,
        y: number,
    },
    end: {
        x: number,
        y: number,
    }
}

interface Path {
    cost: number;
    start: {
        x: number,
        y: number,
    },
    path: Segment[],
}

class App extends Component<{}, AppState> {

    constructor(props: {}) {
        super(props);
        this.state = {
            buildingList: {},
            start: "",
            dest: "",
            parsedLines: [],
            path: {
                cost: 0,
                start: {
                    x: 0,
                    y: 0
                },
                path: []
            },
        };
    }


    /**
     * Sends server request for list of buildings.
     */
    async sendBuildingRequest(){
        let drawPath = fetch(
            "http://localhost:4567/get-buildings");
        let response = await drawPath;
        const buildings = (await response.json());
        this.setState({
            buildingList : buildings,
        });
    }

    /**
     * Sends server request to find the path of start and dest in state.
     */
    async sendPathRequest(){
        let drawPath = await fetch(
            "http://localhost:4567/find-shortest-path?building1=" +
            this.state.start + "&building2=" + this.state.dest);
        let response = await drawPath;
        const path = (await response.json());
        let mapLines : (JSX.Element)[] = [];
        for (let i = 0; i < path.path.length; i++){
            let line : JSX.Element =<MapLine x1={parseInt(path.path[i].start.x)} y1={parseInt(path.path[i].start.y)}
                       x2={parseInt(path.path[i].end.x)} y2={parseInt(path.path[i].end.y)} color = {"red"}/>
            mapLines.push(line);
        }
        this.setState({
            path : path,
            parsedLines: mapLines,
        });
    }

    componentDidMount(){
        this.sendBuildingRequest();
    }

    /**
     * updates the starting building on the dropdown menu
     * @param event the starting building
     */
    startChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        this.setState({
            start: event.target.value,
        })
    }

    /**
     * updates the ending building on the dropdown menu
     * @param event the ending building
     */
    destChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        this.setState({
            dest: event.target.value,
        })
    }

    /**
     * Sends a server request when "draw" is clicked
     */
    drawButtonClick = () => {
        this.sendPathRequest();
    }

    clearButtonClick = () => {
        this.setState({
            start: "",
            dest: "",
            parsedLines : [],
        })
    }

    render() {
        const buildingDropdown = Object.entries(this.state.buildingList);
        return (
            <div className="container">
                <div>
                    <h1 id="app-title">Campus Paths</h1>
                    <div>
                        <Map  parsedLines={this.state.parsedLines}/>
                    </div>
                    <div className="drop-down">
                        <h2>Start</h2>
                        <select onChange={this.startChange} value={this.state.start}>
                            {buildingDropdown.map(([short, long], index) =>
                                <option key={index} value={short}>
                                    {long}
                                </option>)
                            }
                        </select>
                        <h2>Destination</h2>
                        <select onChange={this.destChange} value={this.state.dest}>
                            {buildingDropdown.map(([short, long], index) =>
                                <option key={index} value={short}>
                                    {long}
                                </option>)
                            }
                        </select>
                    </div>
                    <button onClick={this.drawButtonClick}>Draw</button>
                    <button onClick={this.clearButtonClick}>Clear</button>
                    <h3>Note: you must select two buildings before selecting "Draw."</h3>
                </div>
            </div>
        );
    }
}

export default App;

