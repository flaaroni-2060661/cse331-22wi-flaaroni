import React, {Component} from 'react';

interface DropdownState {
    buildingList: Record<string, string>;
    start: string;
    dest: string;
}

interface DropdownProps{
    onChange(startString: string, destString: string):void;
}

class DropdownMenu extends Component<DropdownProps, DropdownState>{

    constructor(props: DropdownProps){
        super(props);
        this.state = {
            buildingList: {},
            start: "",
            dest: "",
        }
    }



    startChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        this.props.onChange(this.state.start, this.state.dest);
        this.setState({
            start: event.target.value,
        });

    }

    destChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        this.props.onChange(this.state.start, this.state.dest);
        this.setState({
            dest: event.target.value,
        });
    }

    render(){
        const buildingList = Object.values(this.state.buildingList);
        return(
            <div>
                <select onChange={this.startChange} value={this.state.start}>
                    {buildingList.map((buildingDropdown, index) =>
                        <option key={index} value={buildingDropdown}>
                            {buildingDropdown}
                        </option>)
                    }
                </select>
                <select onChange={this.destChange} value={this.state.dest}>
                    {buildingList.map((buildingDropdown, index) =>
                        <option key={index}>
                            {buildingDropdown}
                        </option>)
                    }
                </select>
            </div>
        )
    }
}