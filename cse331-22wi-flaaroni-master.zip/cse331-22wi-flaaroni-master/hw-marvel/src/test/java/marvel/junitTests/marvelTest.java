package marvel.junitTests;

import graph.Edge;
import graph.GraphNode;
import graph.MyGraph;
import marvel.MarvelGraph;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class marvelTest {
    @Test
    public void buildGraph(){
        MarvelGraph marvel = new MarvelGraph();
        MyGraph<String, String> test = marvel.buildGraph("staffSuperheroes.csv");
    }

    @Test
    public void buildMarvelGraph(){
        MyGraph<String, String> test = new MyGraph<String, String>();
        test.addNode("HAWK");
        test.addNode("VENUS-II");
        test.addNode("GORILLA-MAN");
        test.addGraphEdge("GORILLA-MAN", "HAWK", "AVF-4");
        test.addGraphEdge("HAWK", "VENUS-II", "AVF-5");
        List<Edge<String, String>> path = MarvelGraph.findPath(test, "GORILLA-MAN", "VENUS-II");
        System.out.print(path);
    }
}
