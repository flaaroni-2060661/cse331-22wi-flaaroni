package marvel;

import graph.Edge;
import graph.EdgeComparator;
import graph.GraphNode;
import graph.MyGraph;
import java.util.*;

import java.util.Scanner;

import static marvel.MarvelParser.parseData;
import java.util.Arrays;
public class MarvelGraph {

    /**
     * Builds a graph made of nodes and edges using the given file
     * @param filename the file the graph is based on
     * @return a graph using the given file
     */
    public MyGraph<String, String> buildGraph (String filename){
        MyGraph<String, String> marvel = new MyGraph<String, String>();
        Map<String, Set<String>> pairs = parseData(filename);
        for (Map.Entry<String, Set<String>> pair : pairs.entrySet()){
            for (String s : pair.getValue()){
                if (!marvel.containsNode(s)) {
                    marvel.addNode(s);
                }
            }
        }
        for (Map.Entry<String, Set<String>> node : pairs.entrySet()){
            for (String s : node.getValue()){
                for (String t: node.getValue()){
                    if (!s.equals(t)){
                        marvel.addGraphEdge(s, t, node.getKey());
                    }
                }
            }
        }
        return marvel;
    }

    /**
     * finds the path from the node "start" to the node "dest"
     * @param marvelGraph the graph the two nodes are in
     * @param start the start of the path
     * @param dest the destination of the path
     * @return a list of edges representing the path from start to dest
     * @throws IllegalArgumentException if either node isn't in marvelGraph
     */
    public static List<Edge<String, String>> findPath(MyGraph<String, String> marvelGraph, String start, String dest) throws IllegalArgumentException{
        if (!marvelGraph.containsNode(start) || !marvelGraph.containsNode(dest)){
            throw new IllegalArgumentException();
        }
        Queue<String> queue = new LinkedList<>();
        queue.add(start);
        Map <String, List<Edge<String, String>>> result = new HashMap<>(); //destination node, path
        result.put(start, new ArrayList<Edge<String, String>>());
        while(!queue.isEmpty()){
            String n = queue.remove();
            if (n.equals(dest)) {
                return result.get(n);
            }
            List<Edge<String, String>> nNode = marvelGraph.graph.get(n);
            EdgeComparator comparator = new EdgeComparator();
            nNode.sort(comparator);
            for (Edge<String, String> e : nNode){
                if (!result.containsKey(e.getChildNode())){
                    List<Edge<String, String>> path = new ArrayList<Edge<String, String>>(result.get(n));
                    path.add(e);
                    result.put(e.getChildNode(), path);
                    queue.add(e.getChildNode());
                }
            }
        }
        return null;
    }

}
